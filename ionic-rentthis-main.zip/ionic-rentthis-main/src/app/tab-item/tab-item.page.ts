import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tab-item',
  templateUrl: './tab-item.page.html',
  styleUrls: ['./tab-item.page.scss'],
  standalone: false,
})
export class TabItemPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
